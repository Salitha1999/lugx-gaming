const express = require('express');
const { ClickHouse } = require('clickhouse');
const app = express();
const PORT = 6000;

app.use(express.json());

// Connect to ClickHouse
const clickhouse = new ClickHouse({
  url: 'http://clickhouse:8123',
  port: 8123,
  basicAuth: {
    username: 'default',
    password: 'secret123', // <-- set to match the YAML
  },
  config: {
    database: 'default',
    session_timeout: 60,
    output_format_json_quote_64bit_integers: 0,
  },
  format: "json",
});



// Create table if not exists (will fail if table already exists)
app.get('/create', async (req, res) => {
  const query = `
    CREATE TABLE IF NOT EXISTS analytics (
      id UUID DEFAULT generateUUIDv4(),
      event_type String,
      page_url String,
      timestamp DateTime DEFAULT now()
    ) ENGINE = MergeTree() ORDER BY timestamp
  `;
  try {
    await clickhouse.query(query).toPromise();
    res.send('✅ Analytics table ready');
  } catch (error) {
    console.error(error);
    res.status(500).send('❌ Error creating table');
  }
});

// POST /track - Accepts user events
app.post('/track', async (req, res) => {
  const { event_type, page_url } = req.body;
  const query = `INSERT INTO analytics (event_type, page_url) VALUES`;
  try {
    await clickhouse.insert(query, [[event_type, page_url]]).toPromise();
    res.status(201).send('✅ Event tracked');
  } catch (error) {
    console.error(error);
    res.status(500).send('❌ Error tracking event');
  }
});

app.listen(PORT, () => {
  console.log(`📊 Analytics Service running at http://localhost:${PORT}`);
});
